import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../features/bookmarks/model/bookmark_model.dart';

class DbHelper {
  static final DbHelper _instance = DbHelper._internal();
  static Database? _database;

  factory DbHelper() => _instance;

  DbHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDb();
    return _database!;
  }

  Future<Database> _initDb() async {
    final path = join(await getDatabasesPath(), 'bookmarks.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
        CREATE TABLE bookmarks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT,
          icon TEXT,
          description TEXT,
          link TEXT,
          collection TEXT,
          tags TEXT
        )
      ''');
      },
    );
  }

  Future<int> insertBookmark(Bookmark bookmark) async {
    final db = await database;
    return await db.insert(
        'bookmarks',
        {
          'title': bookmark.title,
          'icon': bookmark.icon,
          'description': bookmark.description,
          'link': bookmark.link,
          'collection': bookmark.collection,
          'tags':
              bookmark.tags.join(','), // Convert list to comma-separated string
        },
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Bookmark>> getBookmarks() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('bookmarks');

    return List.generate(maps.length, (i) {
      return Bookmark(
        id: maps[i]['id'],
        title: maps[i]['title'],
        icon: maps[i]['icon'],
        description: maps[i]['description'],
        link: maps[i]['link'],
        collection: maps[i]['collection'],
        tags: maps[i]['tags']
            .toString()
            .split(','), // Convert string back to list
      );
    });
  }

  Future<Bookmark?> getBookmarkById(int id) async {
    final db = await database;
    final maps = await db.query(
      'bookmarks',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isNotEmpty) {
      return Bookmark.fromMap(maps.first);
    }
    return null;
  }

  Future<int> updateBookmark(Bookmark bookmark) async {
    final db = await database;
    if (bookmark.id == null) {
      throw Exception("Bookmark ID cannot be null");
    }
    return await db.update(
      'bookmarks',
      {
        'title': bookmark.title,
        'icon': bookmark.icon,
        'description': bookmark.description,
        'link': bookmark.link,
        'collection': bookmark.collection,
        'tags': bookmark.tags.join(','), // Ensure it's stored as a string
      },
      where: 'id = ?',
      whereArgs: [bookmark.id],
    );
  }

  Future<int> deleteBookmark(int id) async {
    final db = await database;
    return await db.delete('bookmarks', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteAllBookmarks() async {
    final db = await database;
    await db.delete('bookmarks');
  }
}
