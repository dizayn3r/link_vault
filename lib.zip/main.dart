import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'features/bookmarks/provider/bookmarks_provider.dart';
import 'features/collections/provider/collections_provider.dart';
import 'features/dashboard/provider/theme_provider.dart';
import 'features/splash/screen/splash_screen.dart';
import 'features/tags/provider/tags_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final themeProvider = ThemeProvider();
  await themeProvider.init(); // Initialize theme before running the app
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => ThemeProvider()),
        ChangeNotifierProvider(create: (context) => BookmarksProvider()),
        ChangeNotifierProvider(create: (context) => CollectionsProvider()),
        ChangeNotifierProvider(create: (context) => TagsProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    return MaterialApp(
      title: 'LinkVault',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: themeProvider.themeMode,
      home: const SplashScreen(),
    );
  }
}
