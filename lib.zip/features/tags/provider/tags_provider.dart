import 'package:flutter/material.dart';

class TagsProvider extends ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  List<String> _tags = [];

  List<String> get tags => _tags;

  setIsLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  setTags(List<String> value) {
    _tags = value;
    notifyListeners();
  }

  getTags() {
    setIsLoading(true);
    setIsLoading(false);
  }
}
