import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../provider/tags_provider.dart';

class TagsScreen extends StatefulWidget {
  const TagsScreen({super.key});

  @override
  State<TagsScreen> createState() => _TagsScreenState();
}

class _TagsScreenState extends State<TagsScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      getTags();
    });
    super.initState();
  }

  void getTags() async {
    final tagsProvider = Provider.of<TagsProvider>(context, listen: false);
    tagsProvider.getTags();
  }

  // void _showCustomDialog(BuildContext context) {
  //   TextEditingController tagController = TextEditingController();
  //
  //   showDialog(
  //     context: context,
  //     builder: (BuildContext context) {
  //       return CustomDialog(
  //         icon: Icons.label_rounded,
  //         title: 'Tag',
  //         label: 'Enter tag name',
  //         controller: tagController,
  //         hintText: 'Tag name',
  //       );
  //     },
  //   ).then((value) {
  //     if (tagController.text.isNotEmpty) {
  //       setState(() {
  //         _savedTags.add(tagController.text);
  //       });
  //     }
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Tags")),
      body: Consumer<TagsProvider>(builder: (context, provider, child) {
        if (provider.isLoading) {
          return CircularProgressIndicator();
        }
        if (!provider.isLoading && provider.tags.isEmpty) {
          return Center(child: Text("No tags yet!"));
        }
        return ListView.builder(
          itemCount: provider.tags.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Text("# ${provider.tags[index]}"),
              trailing: IconButton(
                icon: Icon(Icons.delete, color: Colors.red),
                onPressed: () {},
              ),
            );
          },
        );
      }),
      floatingActionButton: FloatingActionButton(
        mini: true,
        // onPressed: () => _showCustomDialog(context),
        onPressed: () {},
        child: Icon(Icons.add_rounded, size: 16.0),
      ),
    );
  }
}
