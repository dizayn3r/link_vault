import 'package:flutter/material.dart';

import '../../../core/widgets/custom_dialog.dart';

class CollectionsScreen extends StatefulWidget {
  const CollectionsScreen({super.key});

  @override
  State<CollectionsScreen> createState() => _CollectionsScreenState();
}

class _CollectionsScreenState extends State<CollectionsScreen> {
  final List<String> _savedCollections = [];

  void _showCustomDialog(BuildContext context) {
    TextEditingController nameController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return CustomDialog(
          icon: Icons.create_new_folder_rounded,
          title: 'Collection',
          label: 'Enter collection name',
          controller: nameController,
          hintText: 'Name',
        );
      },
    ).then((value) {
      if (nameController.text.isNotEmpty) {
        setState(() {
          _savedCollections.add(nameController.text);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Collections")),
      body: _savedCollections.isEmpty
          ? Center(child: Text("No collections yet!"))
          : ListView.builder(
              itemCount: _savedCollections.length,
              itemBuilder: (context, index) {
                return Card(
                  elevation: 2,
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: Icon(Icons.folder_rounded, color: Colors.amber),
                    title: Text(_savedCollections[index]),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        setState(() {
                          _savedCollections.removeAt(index);
                        });
                      },
                    ),
                    onTap: () {
                      // Open collection action (can be expanded later)
                    },
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        mini: true,
        onPressed: () => _showCustomDialog(context),
        child: Icon(Icons.add_rounded, size: 16.0),
      ),
    );
  }
}
