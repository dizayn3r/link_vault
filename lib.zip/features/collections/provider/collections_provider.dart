import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CollectionsProvider extends ChangeNotifier {
  static const String _collectionsKey = "collections";
  List<String> _collections = [];

  List<String> get collections => _collections;

  CollectionsProvider() {
    _loadCollections();
  }

  Future<void> _loadCollections() async {
    final prefs = await SharedPreferences.getInstance();
    _collections = prefs.getStringList(_collectionsKey) ?? [];
    notifyListeners();
  }

  Future<void> addCollection(String collectionName) async {
    if (collectionName.isNotEmpty && !_collections.contains(collectionName)) {
      _collections.add(collectionName);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_collectionsKey, _collections);
      notifyListeners();
    }
  }

  Future<void> removeCollection(String collectionName) async {
    _collections.remove(collectionName);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_collectionsKey, _collections);
    notifyListeners();
  }
}
