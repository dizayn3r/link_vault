class Collection {
  final int? id;
  final String name;

  Collection({this.id, required this.name});

  Map<String, dynamic> toMap() {
    return {'id': id, 'name': name};
  }

  factory Collection.fromMap(Map<String, dynamic> map) {
    return Collection(id: map['id'], name: map['name']);
  }
}
