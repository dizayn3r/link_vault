import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:link_vault/features/bookmarks/model/bookmark_model.dart';
import 'package:link_vault/features/bookmarks/screen/add_bookmark_screen.dart';

class BookmarkCard extends StatelessWidget {
  final Bookmark bookmark;

  const BookmarkCard({super.key, required this.bookmark});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => AddBookmarkScreen(bookmark: bookmark),
          ),
        );
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16.0),
        ),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.only(
                    left: 8.0,
                    top: 8.0,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(16.0),
                    ),
                  ),
                  child: Image.network(
                    height: 40,
                    width: 40,
                    fit: BoxFit.cover,
                    bookmark.icon.toString(),
                  ),
                ),
                SizedBox(width: 8.0),
                Flexible(
                  child: Text(
                    bookmark.title ?? "No title",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 8.0),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Text(
                bookmark.description ?? "No Description",
                overflow: TextOverflow.ellipsis,
                maxLines: 3,
                style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      bookmark.link ?? "No Link",
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: 14.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(width: 8.0),
                  Icon(
                    Icons.copy_rounded,
                  )
                ],
              ),
            ),
            Row(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 8.0),
                  padding: EdgeInsets.symmetric(
                    horizontal: 12.0,
                    vertical: 8.0,
                  ),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(8.0),
                      bottomRight: Radius.circular(8.0),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.access_time_rounded,
                        color: Theme.of(context).brightness == Brightness.light
                            ? Colors.white
                            : Colors.grey.shade900,
                      ),
                      SizedBox(width: 4.0),
                      Text(
                        DateFormat('EEE, hh:mm a').format(DateTime.now()),
                        style: TextStyle(
                          color:
                              Theme.of(context).brightness == Brightness.light
                                  ? Colors.white
                                  : Colors.grey.shade900,
                        ),
                      ),
                    ],
                  ),
                ),
                Spacer(),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 8.0),
                  padding: EdgeInsets.symmetric(
                    horizontal: 12.0,
                    vertical: 8.0,
                  ),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(8.0),
                      bottomLeft: Radius.circular(8.0),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.folder_outlined,
                        color: Theme.of(context).brightness == Brightness.light
                            ? Colors.white
                            : Colors.grey.shade900,
                      ),
                      SizedBox(width: 4.0),
                      Text(
                        bookmark.collection ?? "No Collection",
                        style: TextStyle(
                          color:
                              Theme.of(context).brightness == Brightness.light
                                  ? Colors.white
                                  : Colors.grey.shade900,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 40.0,
              child: ListView.separated(
                padding: EdgeInsets.symmetric(horizontal: 8.0),
                itemCount: bookmark.tags.length,
                scrollDirection: Axis.horizontal,
                separatorBuilder: (_, __) => SizedBox(width: 8.0),
                itemBuilder: (context, index) {
                  String tag = bookmark.tags[index];
                  return Chip(
                    backgroundColor:
                        Theme.of(context).colorScheme.inversePrimary,
                    side: BorderSide.none,
                    label: Text("#$tag"),
                  );
                },
              ),
            ),
            SizedBox(height: 8.0),
          ],
        ),
      ),
    );
  }
}
