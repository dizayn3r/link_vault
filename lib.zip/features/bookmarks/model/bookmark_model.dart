class Bookmark {
  int? id;
  String? title;
  String? icon;
  String? description;
  String? link;
  String? collection;
  List<String> tags;

  Bookmark({
    this.id,
    this.title,
    this.icon,
    this.description,
    this.link,
    this.collection,
    this.tags = const [],
  });

  factory Bookmark.fromJson(Map<String, dynamic> json) =>
      Bookmark.fromMap(json);

  Map<String, dynamic> toJson() => toMap();

  factory Bookmark.fromMap(Map<String, dynamic> map) => Bookmark(
        id: map["id"],
        title: map["title"],
        icon: map["icon"],
        description: map["description"],
        link: map["link"],
        collection: map["collection"],
        tags: map["tags"] == null
            ? []
            : List<String>.from(map["tags"].map((x) => x)),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "title": title,
        "icon": icon,
        "description": description,
        "link": link,
        "collection": collection,
        "tags": List<dynamic>.from(tags.map((x) => x)),
      };
}
