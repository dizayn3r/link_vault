import 'package:flutter/material.dart';
import 'package:html/parser.dart' as parser;
import 'package:http/http.dart' as http;

import '../../../core/database_helper.dart';
import '../model/bookmark_model.dart';

class BookmarksProvider with ChangeNotifier {
  final DbHelper _dbHelper = DbHelper();

  bool _isLoading = false;

  bool get isLoading => _isLoading;

  List<Bookmark> _bookmarks = [];

  List<Bookmark> get bookmarks => _bookmarks;

  void setIsLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void setBookmarks(List<Bookmark> value) {
    _bookmarks = value;
    notifyListeners();
  }

  void clearBookmarks() {
    _bookmarks.clear();
    notifyListeners();
  }

  Future<void> fetchBookmarks() async {
    setIsLoading(true);
    _bookmarks = await _dbHelper.getBookmarks();
    setIsLoading(false);
  }

  Future<void> addBookmark(Bookmark bookmark) async {
    await _dbHelper.insertBookmark(bookmark);
    await fetchBookmarks();
  }

  Future<void> updateBookmark(Bookmark bookmark) async {
    int num = await _dbHelper.updateBookmark(bookmark);
    if (num == 0) {
      clearBookmarks();
      await fetchBookmarks();
    }
  }

  Future<void> deleteBookmark(int id) async {
    await _dbHelper.deleteBookmark(id);
    await fetchBookmarks();
  }

  Future<Map<String, dynamic>?> getBookmarkInfo(String url) async {
    try {
      final uri = Uri.parse(url);
      final response = await http.get(uri);
      if (response.statusCode == 200) {
        var document = parser.parse(response.body);

        // Extract Title
        String? title = document.querySelector("title")?.text;

        // Extract Description
        String? description = document
            .querySelector("meta[name='description']")
            ?.attributes['content'];

        // Extract Icon
        String? icon =
            document.querySelector("link[rel='icon']")?.attributes['href'] ??
                document
                    .querySelector("link[rel='shortcut icon']")
                    ?.attributes['href'];

        // Convert relative icon URL to absolute if necessary
        if (icon != null && !icon.startsWith("http")) {
          icon = Uri.parse(url).origin + icon;
        }

        return {
          "link": url,
          "title": title ?? "No title found",
          "description": description ?? "No description found",
          "icon": icon ?? "No icon found"
        };
      } else {
        print('Error: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      print('Exception: $e');
      return null;
    }
  }
}
