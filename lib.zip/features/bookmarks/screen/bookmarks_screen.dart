import 'package:flutter/material.dart';
import 'package:link_vault/features/bookmarks/provider/bookmarks_provider.dart';
import 'package:link_vault/features/bookmarks/screen/add_bookmark_screen.dart';
import 'package:link_vault/features/tags/provider/tags_provider.dart';
import 'package:provider/provider.dart';

import '../model/bookmark_model.dart';
import '../widgets/bookmark_card.dart';

class BookmarksScreen extends StatefulWidget {
  const BookmarksScreen({super.key});

  @override
  BookmarksScreenState createState() => BookmarksScreenState();
}

class BookmarksScreenState extends State<BookmarksScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      getLinks();
      getTags();
    });
    super.initState();
  }

  void getLinks() async {
    final linksProvider =
        Provider.of<BookmarksProvider>(context, listen: false);
    await linksProvider.fetchBookmarks();
  }

  void getTags() async {
    final tagsProvider = Provider.of<TagsProvider>(context, listen: false);
    tagsProvider.getTags();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Bookmarks"),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.filter_alt_rounded),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.search_rounded),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: Size(double.infinity, kToolbarHeight),
          child: Container(
            height: kToolbarHeight,
            margin: EdgeInsets.symmetric(
              vertical: 8.0,
              horizontal: 16.0,
            ),
            child: Row(
              children: [
                Consumer<TagsProvider>(
                  builder: (context, provider, child) {
                    if (provider.isLoading) {
                      return CircularProgressIndicator();
                    }
                    if (!provider.isLoading && provider.tags.isEmpty) {
                      return SizedBox.shrink();
                    }
                    return Expanded(
                      child: ListView.separated(
                        itemCount: provider.tags.length,
                        scrollDirection: Axis.horizontal,
                        separatorBuilder: (_, __) => SizedBox(width: 8.0),
                        itemBuilder: (context, index) {
                          String tag = provider.tags[index];
                          return Chip(
                            backgroundColor:
                                Theme.of(context).colorScheme.inversePrimary,
                            side: BorderSide.none,
                            label: Text("#$tag"),
                          );
                        },
                      ),
                    );
                  },
                ),
                IconButton(
                  onPressed: () {},
                  icon: Icon(Icons.filter_list_rounded),
                ),
              ],
            ),
          ),
        ),
      ),
      body: Consumer<BookmarksProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return Center(child: CircularProgressIndicator());
          }
          if (!provider.isLoading && provider.bookmarks.isEmpty) {
            return Center(child: Text("No saved bookmarks yet!"));
          }
          return ListView.builder(
            padding: EdgeInsets.all(8.0),
            itemCount: provider.bookmarks.length,
            itemBuilder: (context, index) {
              Bookmark bookmark = provider.bookmarks[index];
              return BookmarkCard(bookmark: bookmark);
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        mini: true,
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => AddBookmarkScreen(),
            ),
          );
        },
        child: Icon(Icons.add_rounded, size: 16.0),
      ),
    );
  }
}
