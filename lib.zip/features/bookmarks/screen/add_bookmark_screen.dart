import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/widgets/labelled_textfield.dart';
import '../model/bookmark_model.dart';
import '../provider/bookmarks_provider.dart';

class AddBookmarkScreen extends StatefulWidget {
  final Bookmark? bookmark;

  const AddBookmarkScreen({super.key, this.bookmark});

  @override
  _AddBookmarkScreenState createState() => _AddBookmarkScreenState();
}

class _AddBookmarkScreenState extends State<AddBookmarkScreen> {
  final _formKey = GlobalKey<FormState>();
  String iconUrl = "";
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _linkController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _collectionController = TextEditingController();
  final TextEditingController _tagsController = TextEditingController();

  void _saveBookmark() {
    if (_formKey.currentState!.validate()) {
      final bookmark = Bookmark(
        title: _titleController.text,
        link: _linkController.text,
        icon: iconUrl,
        description: _descriptionController.text,
        collection: _collectionController.text,
        tags: _tagsController.text.split(',').map((tag) => tag.trim()).toList(),
      );

      Provider.of<BookmarksProvider>(context, listen: false)
          .addBookmark(bookmark);
      Navigator.pop(context);
    }
  }

  void _updateBookmark() {
    if (_formKey.currentState!.validate()) {
      final bookmark = Bookmark(
        id: widget.bookmark!.id,
        title: _titleController.text,
        link: _linkController.text,
        icon: iconUrl,
        description: _descriptionController.text,
        collection: _collectionController.text,
        tags: _tagsController.text.split(',').map((tag) => tag.trim()).toList(),
      );

      Provider.of<BookmarksProvider>(context, listen: false)
          .updateBookmark(bookmark);
      Navigator.pop(context);
    }
  }

  @override
  void initState() {
    _titleController.text = widget.bookmark?.title ?? '';
    _linkController.text = widget.bookmark?.link ?? '';
    _descriptionController.text = widget.bookmark?.description ?? '';
    iconUrl = widget.bookmark?.icon ?? '';
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final bookmarksProvider =
        Provider.of<BookmarksProvider>(context, listen: false);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(
          widget.bookmark == null ? "Add Bookmark" : "Edit Bookmark",
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () async {
              await bookmarksProvider.deleteBookmark(widget.bookmark!.id!);
              Navigator.pop(context);
            },
          ),
        ],
        bottom: widget.bookmark == null
            ? PreferredSize(
                preferredSize: Size(double.infinity, kToolbarHeight),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: TextFormField(
                    controller: _linkController,
                    decoration: InputDecoration(
                      hintText: "Enter a link",
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: EdgeInsets.only(
                        left: 20.0,
                        top: 8.0,
                        right: 8.0,
                        bottom: 16.0,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(40.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(40.0),
                      ),
                      suffixIcon: InkWell(
                        onTap: () async {
                          final bookmarkProvider =
                              Provider.of<BookmarksProvider>(context,
                                  listen: false);
                          Map<String, dynamic>? info = await bookmarkProvider
                              .getBookmarkInfo(_linkController.text);
                          if (info != null) {
                            setState(() {
                              log("Bookmark Info: ${info}");
                              _titleController.text = info['title'];
                              _descriptionController.text = info['description'];
                              iconUrl = info['icon'];
                            });
                          }
                        },
                        child: Icon(Icons.send_rounded),
                      ),
                    ),
                    validator: (value) =>
                        value!.isEmpty ? "Enter a link" : null,
                  ),
                ),
              )
            : null,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                if (iconUrl.isNotEmpty) Image.network(iconUrl),
                LabelledTextField(
                  label: 'Title',
                  controller: _titleController,
                  hintText: 'Enter a title',
                ),
                SizedBox(height: 8.0),
                LabelledTextField(
                  label: 'Link',
                  controller: _linkController,
                  hintText: 'Enter a link',
                ),
                SizedBox(height: 8.0),
                LabelledTextField(
                  label: 'Description',
                  controller: _descriptionController,
                  hintText: 'Enter a description',
                ),
                SizedBox(height: 8.0),
                LabelledTextField(
                  label: 'Collection',
                  controller: _collectionController,
                  hintText: 'Enter a collection',
                ),
                SizedBox(height: 8.0),
                LabelledTextField(
                  label: 'Tags',
                  controller: _tagsController,
                  hintText: 'Tags (comma separated)',
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed:
                      widget.bookmark == null ? _saveBookmark : _updateBookmark,
                  child: Text(
                    widget.bookmark == null ? "Save" : "Update",
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
